% 加载 params.mat 文件
load('params.mat');

% 遍历 params cell 数组
for k = 1:length(params)
    % 从 cell 数组中提取当前结构体
    currentStruct = params{k};

    % 为每个字段创建变量
    varNames = fieldnames(currentStruct); % 获取所有字段名称
    for n = 1:length(varNames)
        % 使用动态字段名创建变量
        varName = varNames{n};
        eval([varName ' = currentStruct.' varName ';']);
    end

    % 将所有变量保存到单独的文件中
    filename = sprintf('%d_params.mat', k);
    save(filename, varNames{:});
end
