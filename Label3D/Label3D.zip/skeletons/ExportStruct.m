% 加载 .mat 文件
load('my_rat.mat');
%%%%%
% 遍历cell 数组
%for k = 1:length(skeleton)
%    % 从 cell 数组中提取当前结构体
%    currentStruct = sync{k};
%%%%%%
    % 为每个字段创建变量
    %varNames = fieldnames(currentStruct); % 获取所有字段名称
    varNames = fieldnames(skeleton);
    for n = 1:length(varNames)
        % 使用动态字段名创建变量
        varName = varNames{n};
        eval([varName ' = skeleton.' varName ';']);
    end

    % 将所有变量保存到单独的文件中
    %filename = sprintf();
    save('my_rat.mat', varNames{:});
%end
